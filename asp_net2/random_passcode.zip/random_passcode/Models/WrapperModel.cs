using System;
using System.Collections.Generic;

namespace random_passcode.Models
{
    public class WrapperModel
    {
        public string MyPassCode {get;set;}
        public int MyCounter {get;set;}
    }
}//end namespace