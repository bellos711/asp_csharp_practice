using System;
using System.Collections.Generic;

namespace viewmodel_fun.Models
{
    public class User
    {
        public string fName {get;set;}
        public string lName {get;set;}
    }//end class user
}//end namespace